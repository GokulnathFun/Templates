A Pen created at CodePen.io. You can find this one at http://codepen.io/marianarlt/pen/NxWXXd.

 Pure CSS3 animated illustration based on the concept of a page being 'under construction'. Easily change the color theme with one variable.