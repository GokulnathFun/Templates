A Pen created at CodePen.io. You can find this one at http://codepen.io/deanwagman/pen/EjLBdQ.

 First time playing with canvas. Clicking on the screen generates an explosion of particles