A Pen created at CodePen.io. You can find this one at http://codepen.io/Nagendra_HN/pen/YGzBGp.

 Mostly used concepts from digital clocks and designs from other pens on the site