	function loadFunc() {
		setInitialTime();
		window.setInterval(animate, 200);
	}
	var numberToWords = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine", 0: "zero"};
	var numberToWeekdays = {1: "monday", 2: "tuesday", 3: "wednesday", 4: "thursday", 5: "friday", 6: "saturday", 0: "sunday"};
	function setInitialTime() {
		var d = new Date();
		var seconds = d.getSeconds().toString();
		if(seconds.length === 1) {
			seconds = "0" + seconds;
		}
		document.getElementById("seconds2").className = numberToWords[seconds[1]];
		document.getElementById("seconds1").className = numberToWords[seconds[0]];
		var minutes = d.getMinutes().toString();
		if(minutes.length === 1) {
			minutes = "0" + minutes;
		}
		document.getElementById("minutes2").className = numberToWords[minutes[1]];
		document.getElementById("minutes1").className = numberToWords[minutes[0]];
	
		var hours = d.getHours().toString();
		if(hours.length === 1) {
			hours = "0" + hours;
		}
		document.getElementById("hours2").className = numberToWords[hours[1]];
		document.getElementById("hours1").className = numberToWords[hours[0]];
		
		var day = d.getDay().toString();		
		document.querySelector("."+numberToWeekdays[day]).style.color = "black";
	}

	function animate() {
		var d = new Date();
		var seconds = d.getSeconds().toString();
		if(seconds.length === 1) {
			seconds = "0" + seconds;
		}
		if(seconds[1] !== document.getElementById("seconds2").innerText) {
			document.getElementById("seconds2").className = numberToWords[seconds[1]];
		}
	
		if(seconds[0] !== document.getElementById("seconds1").innerText) {
			document.getElementById("seconds1").className = numberToWords[seconds[0]];
		}
	
		var minutes = d.getMinutes().toString();
		if(minutes.length === 1) {
			minutes = "0" + minutes;
		}
		if(minutes[1] !== document.getElementById("minutes2").innerText) {
			document.getElementById("minutes2").className = numberToWords[minutes[1]];
		}
	
		if(minutes[0] !== document.getElementById("minutes1").innerText) {
			document.getElementById("minutes1").className = numberToWords[minutes[0]];
		}
	
		var hours = d.getHours().toString();
		if(document.getElementById("formatChanger").checked) {
			if(hours > 12) {
				hours = hours - 12;
			}
			if(hours.toString().length === 1) {
				hours = "0" + hours.toString();
			} else {
				hours = hours.toString()
			}
		} else {
			if(hours.length === 1) {
				hours = "0" + hours;
			}
		}
	
		if(hours[1] !== document.getElementById("hours2").innerText) {
			document.getElementById("hours2").className = numberToWords[hours[1]];
		}
	
		if(hours[0] !== document.getElementById("hours1").innerText) {
			document.getElementById("hours1").className = numberToWords[hours[0]];
		}
		
		var day = d.getDay().toString();		
		document.querySelector("."+numberToWeekdays[day]).style.color = "black";
	}

	document.getElementById("formatChanger").addEventListener("change", function(evt) {
		var d = new Date();
		el = evt.target;
		if(el.checked) {
			var hours = d.getHours();
			document.querySelector(".indicatorAm").style.opacity = 0;
			document.querySelector(".indicatorPm").style.opacity = 0;
			if(hours > 12) {
				hours = hours - 12;
				document.querySelector(".indicatorPm").style.opacity = 1;
			} else {
				document.querySelector(".indicatorAm").style.opacity = 1;
			}
			if(hours.toString().length === 1) {
				hours = "0" + hours.toString();
			} else {
				hours = hours.toString()
			}
			document.getElementById("hours2").className = numberToWords[hours[1]];
			document.getElementById("hours1").className = numberToWords[hours[0]];
		} else {
			var hours = d.getHours().toString();
			if(hours.length === 1) {
				hours = "0" + hours;
			}
			document.getElementById("hours2").className = numberToWords[hours[1]];
			document.getElementById("hours1").className = numberToWords[hours[0]];
			document.querySelector(".indicatorAm").style.opacity = 0;
			document.querySelector(".indicatorPm").style.opacity = 0;
		}
		document.querySelector(".clockBody").className = "clockBody positionClock";
	});

	document.querySelector(".topPanel").addEventListener("click", function(evt) {
		document.querySelector(".clockBody").className = "clockBody";
		document.querySelector(".clockBody").className += " rotate1";
	});

	document.getElementById("powerButton").addEventListener("click", function(evt) {
		document.querySelector(".clockCover").className = "clockCover clockFace startClock";
		window.setTimeout(function() {
			document.querySelector(".clockCover").className = "clockCover clockFace clockRunning";
			loadFunc();
			document.querySelector(".clockBody").className += " positionClock";
		}, 700)
	});