A Pen created at CodePen.io. You can find this one at http://codepen.io/alexdevero/pen/HIsyr.

 Sliding navigation tutorial without JavaScript using only HTML5 and CSS3 technologies. Tutorial available on http://alexsblog.org/2014/07/21/sliding-navigation-tutorial-without-javascript/