A Pen created at CodePen.io. You can find this one at http://codepen.io/mohab-elhamzawy/pen/EaEQxG.

 Adidas logo with colors switcher