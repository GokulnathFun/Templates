A Pen created at CodePen.io. You can find this one at http://codepen.io/MaCeLMp4/pen/HbDFB.

 Image Hover Effects By http://studiomp4.hol.es