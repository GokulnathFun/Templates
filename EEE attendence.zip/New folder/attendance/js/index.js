$(document).ready(function(){
  var check_count = 0;
  var total = 0;
  var saveLastRemovedItem;
  var saveLastRemovedItemIndex;

  // -****Custom Functions****-
  function updateText(){
    $('#count').text(total);
    $('#count_done').text(check_count);
    $('#remaining_done').text(total-check_count);
  }
  function showDate(){
    var suffix = "";
    var date = new Date();
    var dayOfMonth = date.getDate();
    var dayOfWeek = date.getDay();
    var Month = date.getMonth();
    var DateCache =  $('.app .info .date');

    var dayArray = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var monthArray = ["January","February","March","April,","May","June","July","August","September","October","November","December"];
    switch(dayOfMonth) {
        case 1: case 21: case 31: suffix = 'st'; break;
        case 2: case 22:          suffix = 'nd'; break;
        case 3: case 23:          suffix = 'rd'; break;
        default:                  suffix = 'th';
    }
    DateCache.find('#today').text(dayArray[dayOfWeek] + ",");
    DateCache.find('#daymonth').text(" " + dayOfMonth + suffix);
    DateCache.find('#month').text(monthArray[Month]);
  }
  // Get the total number of "li's" and checked "li's"
  function loadLi(){
    var findTheMarkedList = $('ul li');
    for(var i = 0; i < findTheMarkedList.length;i++){
      total++;
      if($(findTheMarkedList[i]).find('i').hasClass('fa-check-circle mark')){
          $('li .right').eq(i).find('p').addClass('line-through').attr("contentEditable", false);
          check_count++;
        }
      }
      updateText();
    }
  // -**End Custom Functions**-

  showDate();
  loadLi();

  // Click on button function add new item to list
  $('.bottom #add-new').click(function(e){
    e.preventDefault();
    var li = "";

      li += "<li class='slide'>";
      li += " <a href='' class='check_button' onmousedown='return false'>";
      li += "   <i class='fa fa-circle-thin' aria-hidden='true'></i>";
      li += " </a>";
      li += " <div class='right'>";
      li += "    <p contenteditable='true'><strong></strong></p>";
      li += " </div>";
      li += " <span class='delete_button' onmousedown='return false'>";
      li += "   <i class='fa fa-minus' aria-hidden='true'></i>";
      li += " </span>";
      li += "</li>";

    $('ul').append(li).find('.slide:last-child').addClass('down');

    total+=1;
    $('li:last-child p').text('New Task');

    updateText();
  });
  // Click on button function list
  $('.app ul').on('click','li .check_button',function(e){
    e.preventDefault();

    let button = $(this).find('i');
    let checked = 'fa fa-check-circle mark';
    let unchecked = 'fa fa-circle-thin';

    // Save the current index of button after the click event in the "left" div.
    let index_click = $('li .check_button').index(this);
    // Use the current index of button to target the correct "li p" in the "right" div.
    let linethrough_text = $('li .right').eq(index_click).find('p');

    if(button.hasClass(unchecked)){
      linethrough_text.addClass('line-through').attr("contentEditable", false);
      button.removeClass(unchecked + ' mark-alt').addClass('pop_in').addClass(checked);
      check_count +=1;
    }
    else{
      linethrough_text.removeClass('line-through').attr('contentEditable', true);
      button.removeClass(checked).removeClass('pop_in').addClass(unchecked + ' mark-alt');
      check_count -=1;
    }

    updateText();
  });
  // Click on button function and delete 'li'
  $('.app ul').on('click','li .delete_button',function(e){
    e.preventDefault();
    let index_click = $( 'li .delete_button' ).index(this);
    let current = $('li').eq(index_click);
    let button = $('.check_button').find('i');

    $(this).prop("disabled", true);
    total -= 1;

    saveLastRemovedItem = current.clone();
    saveLastRemovedItemIndex = $( 'li .delete_button' ).index(this);

    if(button.eq(index_click).hasClass('mark')){
      check_count -=1;
    }

    current.addClass('up');
    setTimeout(function () {
      current.remove();
    }, 560);

    $('#undo').removeClass('pop_out').addClass('pop_in').prop('disabled', false);

    updateText();
  });
  // Undo buton
  $('.app .bottom').on('click','#undo',function(e){
    e.preventDefault();
    console.log(saveLastRemovedItemIndex);
    total += 1;

    if(saveLastRemovedItem.find('i').hasClass('mark')){
      check_count +=1;
    }

    if(saveLastRemovedItemIndex > 0){
    	$(saveLastRemovedItem).insertAfter('li:nth-child(' + (saveLastRemovedItemIndex+1) +')').addClass('down');
    }else{
    	$(saveLastRemovedItem).insertAfter('#today2').addClass('down');
    }
    $(this).removeClass('pop_in').addClass('pop_out');

    updateText();
  });
});
