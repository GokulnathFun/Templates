A Pen created at CodePen.io. You can find this one at http://codepen.io/tns301/pen/mmpMQN.

 A simple todo list built with jQuery.

Update v1.1
-  Added a button to undo a previous deleted item.
-  Added a function to update text.

Update v1.11
-  Undo a previous deleted item and place it back to the original position