A Pen created at CodePen.io. You can find this one at http://codepen.io/sanisinhere/pen/HpElF.

 simple image slider for website showcase.