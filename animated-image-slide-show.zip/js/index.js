var a=setInterval(function(){change()},4000);
var n=2;
function change()
{
document.getElementById("i").src="http://developtest.uphero.com/im/image-slider-"+n+".jpg";
document.getElementById(n).checked="checked";

if(n==1)
{
document.getElementById("sc").innerHTML="Welcome";
}
else if(n==2)
{
document.getElementById("sc").innerHTML="Contents";
document.getElementById(n).checked="checked";
}
else if(n==3)
{
document.getElementById("sc").innerHTML="Contents";
document.getElementById(n).checked="checked";
}
else if(n==4)
{
document.getElementById("sc").innerHTML="Contents";
document.getElementById(n).checked="checked";
}
n++;
if(n==5)
{
n=1;
}
}

function changenum(a)
{
n=a;
}