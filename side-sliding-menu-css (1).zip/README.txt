A Pen created at CodePen.io. You can find this one at http://codepen.io/EduardL/pen/aBGAy.

 CSS Sliding menu with scroll, no JS were used