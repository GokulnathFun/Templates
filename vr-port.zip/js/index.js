document.querySelector('.to_lv').addEventListener('click', function () {
  window.location.href = $(this).data('url');
});