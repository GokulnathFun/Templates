var audio=document.querySelector("audio");
$(".button").click(function(){
  if($(".button").html()=="Mute"){
    $(".button").html("Play");
    audio.pause();
  }
  else{
    $(".button").html("Mute");
    audio.play();
  }
})