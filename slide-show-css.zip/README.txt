A Pen created at CodePen.io. You can find this one at http://codepen.io/maxnguyen/pen/goyEp.

 Make the slide show using only CSS Tricks