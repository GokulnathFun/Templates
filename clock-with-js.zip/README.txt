A Pen created at CodePen.io. You can find this one at http://codepen.io/EleftheriaBatsou/pen/RRYgqP.

 This is a demonstration of a digital clock, displaying time with the current- time function in Javascript