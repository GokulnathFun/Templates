A Pen created at CodePen.io. You can find this one at http://codepen.io/kristofferh/pen/LpNGqE.

 This is an old thing I made -- 5 years ago? Something like that. Just moving it over from jsdo.it. 