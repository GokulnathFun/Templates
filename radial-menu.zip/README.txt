A Pen created at CodePen.io. You can find this one at http://codepen.io/adamlukem/pen/RWVyxZ.

 A circular navigation bar using pure CSS animation and bourbon for vendor prefixes