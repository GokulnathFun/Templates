A Pen created at CodePen.io. You can find this one at http://codepen.io/daniel_wolf/pen/yNBGoG.

 Here's a simulation of a Contact list app with my some cool switching tab panel effects I did. The lists also have a nice bouncy effect and combined with some blur it really makes for a smooth transition between tabs.

Works best in Chrome :D
