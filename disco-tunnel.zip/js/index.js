console.clear();
var mEls = document.querySelectorAll(".cyl marquee");

[].forEach.call(mEls, function(e, i) {
  setInterval(function() {
    if(e.style.color === "rgba(0, 0, 0, 0)") {
      var h = Math.random()*360>>0;
      var s = 100;
      var l = 75;
      e.style.color = "hsl("+ h + ", " + s + "%, " + l + "%)";
    } else {
      e.style.color = "rgba(0, 0, 0, 0)";
    }
  }, 200 + (i/(mEls.length-1) * 200));
});