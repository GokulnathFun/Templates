function lFunction() {
    document.getElementById("lnav").style.display = "block";
}
function rFunction() {
    document.getElementById("rnav").style.display = "block";
}