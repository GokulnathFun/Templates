A Pen created at CodePen.io. You can find this one at http://codepen.io/gregh/pen/yVLOyO.

 A game made to inspire developers to use GSAP, ES6 and Flexbox