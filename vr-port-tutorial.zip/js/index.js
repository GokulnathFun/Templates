document.querySelector('#finish').addEventListener('click', function () {
  alert('Finish!');
});

$(document).ready(function() {
    setTimeout(function() {
      $(".a-enter-vr").trigger('click');
    },100);
});