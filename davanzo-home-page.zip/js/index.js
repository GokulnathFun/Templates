$('body').addClass('home');
$(document).on('click', '.header-nav .copy h2', function(){
  $('body').toggleClass('devMode');
});

var headerHeight;

$(window).scroll(function(){
  var pageTop = $(window).scrollTop(),
      scale		= 1-pageTop;
});

// DRIBBBLE API
var gotShots = function (playerShots) {
  var html 				= '',
      shotsArray	= playerShots.shots,
      totalShots	= playerShots.shots.length;
  
  console.log(shotsArray);
  
	for (var i = 0; i < totalShots; i++) {
    var shot							= shotsArray[i],
    		id								= shot.id,
        image_400_url			= shot.image_400_url,
        image_teaser_url	= shot.image_teaser_url,
        image_url					= shot.image_url,
        likes_count				= shot.likes_count,
        views_count				= shot.views_count,
    		title							= shot.title,
        url								= shot.url,
        short_url					= shot.short_url,
    		myDelay						= i*60+'ms';
    
    //console.log(title, id, short_url, likes_count, views_count);
    
    html += '<li style="transition-delay:' + myDelay + '; -webkit-transition-delay:' + myDelay + '">';
    html += '<a href="' + url + '" target="_blank">';
    html += '<div class="info flex-it flex-column flex-align-item-end flex-justify-end"><div class="details">';
    html += '<p class="heart">❤</p><h2 class="likes_count">' + likes_count + '</h2></div></div>';
    html += '<img src="' + image_url + '" ';
    html += 'alt="' + title + '"></a></li>';
    
    //console.log('my delay will be '+ myDelay);
  }

  $('.dribbble ul').html(html);
};

$.jribbble.getShotsByPlayerId('marcelodavanzo', gotShots, {page:1, per_page:11});

// KILL LOADER
$(window).on('load', function(){
  $('.header-nav').removeClass('loading');
  
  // GET HEADER HEIGHT
  setTimeout(function(){
    headerHeight = $('.header-nav').outerHeight();
		console.log('header height is '+ headerHeight);
  }, 1200);
});

// WAYPOINTS
var waypoints = $('#dribbble').waypoint(function(direction) {
  console.log(this.element.id + ' hit');
  $('#dribbble').toggleClass('visible');
}, {
  offset: '25%'
});